---
layout: page
title: About
permalink: /about/
---

Jekyll Paper is a simple Jekyll theme, and it is aim to helping you to create your own blog by the easiest way.

You can find more information in [Jekyll Paper][jekyll-paper]. If you have any questions or suggestions, you can contact me in [Jekyll Paper Issues][jekyll-paper-issues] or send email to [me](mailto:i@ghosind.com). Wish you enjoying your blog life!

[jekyll-paper]: https://github.com/ghosind/Jekyll-Paper
[jekyll-paper-issues]: https://github.com/ghosind/Jekyll-Paper/issues